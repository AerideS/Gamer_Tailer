----------------------------------------------
     SPUM : Soonsoon Pixel Unit Maker
	   Monster Undead Pack - SPUM Premium Addon
     Copyright © 2021 Soonsoon
----------------------------------------------

Thanks for buying SPUM Premium Addon - Monster Undead Pack for your game project!!

PLEASE NOTE that SPUM Premium Addon - Monster Undead Pack can only be legally downloaded from the following 1 sources:

  1. Unity Asset Store (Standard License)

If you've obtained SPUM Premium Addon - Monster Undead Pack via some other means then note that your license is effectively invalid,
as Soonsoon cannot provide support for pirated and/or potentially modified software.

If you have any questions, please contact to soonsoon@soonsoons.com

-----------------
 How to use
-----------------
1. This addon is basically a sprite resource pack for use with SPUM.
2. You can using Sprites in Assets/SPUM/SPUM_Sprites/Packages/MonsterUndead
3. If you want to custom Unit by SPUM and This Addon, You have to get SPUM from this URL.
  https://assetstore.unity.com/packages/slug/188715
4. This add-on works with SPUM version 1.50 or higher.
5. If you want to custom Unit by SPUM and This Addon, You have to copy this package folder to SPUM project and Re-install sprites in SPUM_Manager Object.
6. You can use Prefabs Units for you project standalone without SPUM.
   ( But this case, you can not edit or modifying custom unit with useful editor ) 
   ( We recommand using with SPUM )



-----------------
 Version History
-----------------
1.0.2
- fixed : Minor bug fixed.
1.0.0
- New  : First Upload version



